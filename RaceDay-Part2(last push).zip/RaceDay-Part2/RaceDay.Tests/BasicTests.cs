using Microsoft.AspNetCore.Identity;
using RaceDay.Api.Models;
using Xunit;

namespace RaceDay.Tests;

public sealed class BasicTests
{
    [Theory]
    [InlineData("Organizer", true)]
    [InlineData("Participant", true)]
    [InlineData("Admin", false)]
    [InlineData("", false)]
    [InlineData("organizer", false)]
    public void OnlySupportedRolesAreAccepted(string role, bool expected) => Assert.Equal(expected, Roles.IsValid(role));

    [Fact]
    public void PasswordHasherDoesNotStorePlainTextAndCanVerifyPassword()
    {
        var user = new ApplicationUser { Email = "student@example.com", FullName = "Test Student", Role = Roles.Participant };
        var hasher = new PasswordHasher<ApplicationUser>();
        user.PasswordHash = hasher.HashPassword(user, "GoodPass1!");
        Assert.NotEqual("GoodPass1!", user.PasswordHash);
        Assert.Equal(PasswordVerificationResult.Success, hasher.VerifyHashedPassword(user, user.PasswordHash, "GoodPass1!"));
        Assert.Equal(PasswordVerificationResult.Failed, hasher.VerifyHashedPassword(user, user.PasswordHash, "WrongPass1!"));
    }

    [Fact]
    public void EventTypeValidationAcceptsOnlyRunWalkOrCycle()
    {
        static bool Valid(string value) => new[] { "run", "walk", "cycle" }.Contains(value.ToLowerInvariant());
        Assert.True(Valid("RUN")); Assert.True(Valid("walk")); Assert.True(Valid("Cycle"));
        Assert.False(Valid("swim"));
    }
}
