using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using RaceDay.Api.Contracts;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
using RaceDay.Api.Security;

var builder = WebApplication.CreateBuilder(args);
var connectionString = builder.Configuration.GetConnectionString("RaceDayDb")
    ?? "Server=(localdb)\\MSSQLLocalDB;Database=RaceDayDb;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True";
builder.Services.AddDbContext<RaceDayDbContext>(options => options.UseSqlServer(connectionString));
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.Cookie.Name = ".RaceDay.Session";
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.IdleTimeout = TimeSpan.FromMinutes(30);
});
builder.Services.AddScoped<IPasswordHasher<ApplicationUser>, PasswordHasher<ApplicationUser>>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo { Title = "RaceDay API", Version = "v1", Description = "RaceDay event management API. Login first to establish a session cookie." });
});
builder.Services.AddProblemDetails();

var app = builder.Build();
app.UseExceptionHandler();
app.UseHttpsRedirection();
app.UseSession();
app.UseSwagger();
app.UseSwaggerUI();

app.MapGet("/", () => Results.Ok(new { name = "RaceDay API", swagger = "/swagger", status = "running" })).WithTags("System");
app.MapGet("/api/health", () => Results.Ok(new { status = "Healthy", utc = DateTime.UtcNow })).WithTags("System");

var auth = app.MapGroup("/api/auth").WithTags("Authentication");
auth.MapPost("/register", async (RegisterRequest request, RaceDayDbContext db, IPasswordHasher<ApplicationUser> hasher) =>
{
    if (string.IsNullOrWhiteSpace(request.FullName) || string.IsNullOrWhiteSpace(request.Email) || !request.Email.Contains('@') || string.IsNullOrWhiteSpace(request.Password))
        return Results.BadRequest(new { message = "Full name, valid email and password are required." });
    if (request.Password.Length < 8 || !request.Password.Any(char.IsUpper) || !request.Password.Any(char.IsDigit) || !request.Password.Any(c => !char.IsLetterOrDigit(c)))
        return Results.BadRequest(new { message = "Password must be at least 8 characters and include an uppercase letter, a number and a special character." });
    if (!Roles.IsValid(request.Role)) return Results.BadRequest(new { message = "Role must be Organizer or Participant." });
    var email = request.Email.Trim().ToLowerInvariant();
    if (await db.Users.AnyAsync(u => u.Email == email)) return Results.Conflict(new { message = "An account with this email already exists." });
    var user = new ApplicationUser { FullName = request.FullName.Trim(), Email = email, Role = request.Role, CreatedAtUtc = DateTime.UtcNow };
    user.PasswordHash = hasher.HashPassword(user, request.Password);
    db.Users.Add(user);
    await db.SaveChangesAsync();
    return Results.Created($"/api/users/{user.Id}", new { user.Id, user.FullName, user.Email, user.Role });
}).WithSummary("Register a new Organizer or Participant account");

auth.MapPost("/login", async (LoginRequest request, HttpContext context, RaceDayDbContext db, IPasswordHasher<ApplicationUser> hasher) =>
{
    var email = request.Email.Trim().ToLowerInvariant();
    var user = await db.Users.SingleOrDefaultAsync(u => u.Email == email);
    if (user is null || hasher.VerifyHashedPassword(user, user.PasswordHash, request.Password) == PasswordVerificationResult.Failed)
        return Results.Unauthorized();
    context.Session.Clear();
    context.Session.SetInt32(SessionUser.UserIdKey, user.Id);
    context.Session.SetString(SessionUser.RoleKey, user.Role);
    context.Session.SetString(SessionUser.NameKey, user.FullName);
    return Results.Ok(new { message = "Login successful. Keep the session cookie for subsequent requests.", user.Id, user.FullName, user.Email, user.Role });
}).WithSummary("Login and create a server-side session");

auth.MapPost("/logout", (HttpContext context) => { context.Session.Clear(); return Results.Ok(new { message = "Logged out." }); });
auth.MapGet("/me", async (HttpContext context, RaceDayDbContext db) =>
{
    var id = SessionUser.Id(context);
    if (id is null) return Results.Unauthorized();
    var user = await db.Users.Where(u => u.Id == id).Select(u => new { u.Id, u.FullName, u.Email, u.Role }).SingleOrDefaultAsync();
    return user is null ? Results.Unauthorized() : Results.Ok(user);
});

var users = app.MapGroup("/api/users").WithTags("User profile");
users.MapGet("/me", async (HttpContext context, RaceDayDbContext db) =>
{
    var id = SessionUser.Id(context); if (id is null) return Results.Unauthorized();
    var user = await db.Users.Where(u => u.Id == id).Select(u => new { u.Id, u.FullName, u.Email, u.Role, u.CreatedAtUtc }).SingleOrDefaultAsync();
    return user is null ? Results.Unauthorized() : Results.Ok(user);
});
users.MapPut("/me", async (UpdateProfileRequest request, HttpContext context, RaceDayDbContext db) =>
{
    var id = SessionUser.Id(context); if (id is null) return Results.Unauthorized();
    if (string.IsNullOrWhiteSpace(request.FullName) || string.IsNullOrWhiteSpace(request.Email) || !request.Email.Contains('@')) return Results.BadRequest(new { message = "Full name and valid email are required." });
    var user = await db.Users.FindAsync(id.Value); if (user is null) return Results.Unauthorized();
    var email = request.Email.Trim().ToLowerInvariant();
    if (await db.Users.AnyAsync(u => u.Email == email && u.Id != id.Value)) return Results.Conflict(new { message = "Email is already in use." });
    user.FullName = request.FullName.Trim(); user.Email = email; await db.SaveChangesAsync();
    context.Session.SetString(SessionUser.NameKey, user.FullName);
    return Results.Ok(new { user.Id, user.FullName, user.Email, user.Role });
});

var events = app.MapGroup("/api/events").WithTags("Events");
events.MapGet("/", async (RaceDayDbContext db) => Results.Ok(await db.Events.AsNoTracking().OrderBy(e => e.EventDate).Select(e => new { e.Id, e.Name, e.Description, e.EventDate, e.Location, e.DistanceKm, e.EventType, e.OrganizerId }).ToListAsync()));
events.MapGet("/{id:int}", async (int id, RaceDayDbContext db) =>
{
    var item = await db.Events.AsNoTracking().Where(e => e.Id == id).Select(e => new { e.Id, e.Name, e.Description, e.EventDate, e.Location, e.DistanceKm, e.EventType, e.OrganizerId, Categories = e.Categories.Select(c => new { c.CategoryId, c.Category!.Name, c.Category.AgeGroup, c.Category.DistanceKm }) }).SingleOrDefaultAsync();
    return item is null ? Results.NotFound() : Results.Ok(item);
});
events.MapPost("/", async (EventRequest request, HttpContext context, RaceDayDbContext db) =>
{
    if (!SessionUser.IsRole(context, Roles.Organizer)) return SessionUser.Id(context) is null ? Results.Unauthorized() : Results.Forbid();
    if (string.IsNullOrWhiteSpace(request.Name) || string.IsNullOrWhiteSpace(request.Location) || request.DistanceKm <= 0 || request.EventDate == default || !new[] { "run", "walk", "cycle" }.Contains(request.EventType.ToLowerInvariant()))
        return Results.BadRequest(new { message = "Name, location, date, positive distance and event type run/walk/cycle are required." });
    var item = new Event { Name = request.Name.Trim(), Description = request.Description?.Trim() ?? "", EventDate = request.EventDate, Location = request.Location.Trim(), DistanceKm = request.DistanceKm, EventType = request.EventType.ToLowerInvariant(), OrganizerId = SessionUser.Id(context)!.Value };
    db.Events.Add(item); await db.SaveChangesAsync(); return Results.Created($"/api/events/{item.Id}", item);
});
events.MapPut("/{id:int}", async (int id, EventRequest request, HttpContext context, RaceDayDbContext db) =>
{
    if (!SessionUser.IsRole(context, Roles.Organizer)) return SessionUser.Id(context) is null ? Results.Unauthorized() : Results.Forbid();
    var item = await db.Events.FindAsync(id); if (item is null) return Results.NotFound();
    if (item.OrganizerId != SessionUser.Id(context)) return Results.Forbid();
    if (string.IsNullOrWhiteSpace(request.Name) || string.IsNullOrWhiteSpace(request.Location) || request.DistanceKm <= 0 || !new[] { "run", "walk", "cycle" }.Contains(request.EventType.ToLowerInvariant())) return Results.BadRequest(new { message = "Invalid event fields." });
    item.Name = request.Name.Trim(); item.Description = request.Description?.Trim() ?? ""; item.EventDate = request.EventDate; item.Location = request.Location.Trim(); item.DistanceKm = request.DistanceKm; item.EventType = request.EventType.ToLowerInvariant();
    await db.SaveChangesAsync(); return Results.Ok(item);
});
events.MapDelete("/{id:int}", async (int id, HttpContext context, RaceDayDbContext db) =>
{
    if (!SessionUser.IsRole(context, Roles.Organizer)) return SessionUser.Id(context) is null ? Results.Unauthorized() : Results.Forbid();
    var item = await db.Events.FindAsync(id); if (item is null) return Results.NotFound(); if (item.OrganizerId != SessionUser.Id(context)) return Results.Forbid();
    db.Events.Remove(item); await db.SaveChangesAsync(); return Results.NoContent();
});
events.MapPost("/{id:int}/categories/{categoryId:int}", async (int id, int categoryId, HttpContext context, RaceDayDbContext db) =>
{
    if (!SessionUser.IsRole(context, Roles.Organizer)) return SessionUser.Id(context) is null ? Results.Unauthorized() : Results.Forbid();
    var item = await db.Events.FindAsync(id); if (item is null) return Results.NotFound(new { message = "Event not found." });
    if (item.OrganizerId != SessionUser.Id(context)) return Results.Forbid();
    if (!await db.Categories.AnyAsync(c => c.Id == categoryId)) return Results.NotFound(new { message = "Category not found." });
    if (await db.EventCategories.AnyAsync(ec => ec.EventId == id && ec.CategoryId == categoryId)) return Results.Conflict(new { message = "Category already assigned." });
    db.EventCategories.Add(new EventCategory { EventId = id, CategoryId = categoryId }); await db.SaveChangesAsync(); return Results.Ok(new { message = "Category assigned to event." });
});

var categories = app.MapGroup("/api/categories").WithTags("Categories");
categories.MapGet("/", async (RaceDayDbContext db) => Results.Ok(await db.Categories.AsNoTracking().OrderBy(c => c.Name).ToListAsync()));
categories.MapPost("/", async (CategoryRequest request, HttpContext context, RaceDayDbContext db) =>
{
    if (!SessionUser.IsRole(context, Roles.Organizer)) return SessionUser.Id(context) is null ? Results.Unauthorized() : Results.Forbid();
    if (string.IsNullOrWhiteSpace(request.Name) || (request.DistanceKm.HasValue && request.DistanceKm <= 0)) return Results.BadRequest(new { message = "Category name is required and distance must be positive." });
    var item = new Category { Name = request.Name.Trim(), AgeGroup = request.AgeGroup?.Trim(), DistanceKm = request.DistanceKm };
    db.Categories.Add(item); await db.SaveChangesAsync(); return Results.Created($"/api/categories/{item.Id}", item);
});
categories.MapPut("/{id:int}", async (int id, CategoryRequest request, HttpContext context, RaceDayDbContext db) =>
{
    if (!SessionUser.IsRole(context, Roles.Organizer)) return SessionUser.Id(context) is null ? Results.Unauthorized() : Results.Forbid();
    var item = await db.Categories.FindAsync(id); if (item is null) return Results.NotFound();
    if (string.IsNullOrWhiteSpace(request.Name) || (request.DistanceKm.HasValue && request.DistanceKm <= 0)) return Results.BadRequest(new { message = "Invalid category fields." });
    item.Name = request.Name.Trim(); item.AgeGroup = request.AgeGroup?.Trim(); item.DistanceKm = request.DistanceKm; await db.SaveChangesAsync(); return Results.Ok(item);
});

var enrolments = app.MapGroup("/api/enrolments").WithTags("Event enrolments");
enrolments.MapPost("/{eventId:int}", async (int eventId, EnrolRequest request, HttpContext context, RaceDayDbContext db) =>
{
    if (!SessionUser.IsRole(context, Roles.Participant)) return SessionUser.Id(context) is null ? Results.Unauthorized() : Results.Forbid();
    if (!await db.Events.AnyAsync(e => e.Id == eventId)) return Results.NotFound(new { message = "Event not found." });
    if (!await db.EventCategories.AnyAsync(ec => ec.EventId == eventId && ec.CategoryId == request.CategoryId)) return Results.BadRequest(new { message = "Choose a category assigned to this event." });
    var userId = SessionUser.Id(context)!.Value;
    if (await db.EventEnrolments.AnyAsync(x => x.EventId == eventId && x.ParticipantId == userId)) return Results.Conflict(new { message = "You are already enrolled in this event." });
    var item = new EventEnrolment { EventId = eventId, ParticipantId = userId, CategoryId = request.CategoryId };
    db.EventEnrolments.Add(item); await db.SaveChangesAsync(); return Results.Created($"/api/enrolments/{item.Id}", new { item.Id, item.EventId, item.ParticipantId, item.CategoryId, item.EnrolledAtUtc });
});
enrolments.MapGet("/mine", async (HttpContext context, RaceDayDbContext db) =>
{
    if (!SessionUser.IsRole(context, Roles.Participant)) return SessionUser.Id(context) is null ? Results.Unauthorized() : Results.Forbid();
    var userId = SessionUser.Id(context)!.Value;
    return Results.Ok(await db.EventEnrolments.AsNoTracking().Where(x => x.ParticipantId == userId).Select(x => new { x.Id, x.EventId, EventName = x.Event!.Name, x.CategoryId, CategoryName = x.Category!.Name, x.EnrolledAtUtc }).ToListAsync());
});
enrolments.MapGet("/event/{eventId:int}", async (int eventId, HttpContext context, RaceDayDbContext db) =>
{
    if (!SessionUser.IsRole(context, Roles.Organizer)) return SessionUser.Id(context) is null ? Results.Unauthorized() : Results.Forbid();
    if (!await db.Events.AnyAsync(e => e.Id == eventId && e.OrganizerId == SessionUser.Id(context))) return Results.NotFound(new { message = "Event not found or not owned by this organiser." });
    return Results.Ok(await db.EventEnrolments.AsNoTracking().Where(x => x.EventId == eventId).Select(x => new { x.Id, x.ParticipantId, ParticipantName = x.Participant!.FullName, x.CategoryId, CategoryName = x.Category!.Name, x.EnrolledAtUtc }).ToListAsync());
});

var results = app.MapGroup("/api/results").WithTags("Results");
results.MapPost("/events/{eventId:int}", async (int eventId, ResultRequest request, HttpContext context, RaceDayDbContext db) =>
{
    if (!SessionUser.IsRole(context, Roles.Organizer)) return SessionUser.Id(context) is null ? Results.Unauthorized() : Results.Forbid();
    if (!await db.Events.AnyAsync(e => e.Id == eventId && e.OrganizerId == SessionUser.Id(context))) return Results.NotFound(new { message = "Event not found or not owned by this organiser." });
    if (request.FinishPosition <= 0) return Results.BadRequest(new { message = "Finish position must be greater than zero." });
    if (!await db.EventEnrolments.AnyAsync(x => x.EventId == eventId && x.ParticipantId == request.ParticipantId)) return Results.BadRequest(new { message = "Participant must be enrolled before a result can be recorded." });
    TimeSpan? finishTime = null;
    if (!string.IsNullOrWhiteSpace(request.FinishTime) && (!TimeSpan.TryParse(request.FinishTime, out var parsed) || parsed < TimeSpan.Zero)) return Results.BadRequest(new { message = "FinishTime must be a valid non-negative duration such as 00:42:15." });
    else if (!string.IsNullOrWhiteSpace(request.FinishTime)) finishTime = TimeSpan.Parse(request.FinishTime);
    var item = await db.EventResults.SingleOrDefaultAsync(x => x.EventId == eventId && x.ParticipantId == request.ParticipantId);
    if (item is null) { item = new EventResult { EventId = eventId, ParticipantId = request.ParticipantId }; db.EventResults.Add(item); }
    item.FinishTime = finishTime; item.FinishPosition = request.FinishPosition; item.RecordedAtUtc = DateTime.UtcNow;
    await db.SaveChangesAsync(); return Results.Ok(new { item.Id, item.EventId, item.ParticipantId, item.FinishTime, item.FinishPosition, item.RecordedAtUtc });
});
results.MapGet("/mine", async (HttpContext context, RaceDayDbContext db) =>
{
    if (!SessionUser.IsRole(context, Roles.Participant)) return SessionUser.Id(context) is null ? Results.Unauthorized() : Results.Forbid();
    var userId = SessionUser.Id(context)!.Value;
    return Results.Ok(await db.EventResults.AsNoTracking().Where(x => x.ParticipantId == userId).OrderBy(x => x.Event!.EventDate).Select(x => new { x.Id, x.EventId, EventName = x.Event!.Name, x.FinishTime, x.FinishPosition, x.RecordedAtUtc }).ToListAsync());
});
results.MapGet("/events/{eventId:int}", async (int eventId, HttpContext context, RaceDayDbContext db) =>
{
    if (SessionUser.Id(context) is null) return Results.Unauthorized();
    if (SessionUser.Role(context) == Roles.Organizer && !await db.Events.AnyAsync(e => e.Id == eventId && e.OrganizerId == SessionUser.Id(context))) return Results.Forbid();
    if (SessionUser.Role(context) is not (Roles.Organizer or Roles.Participant)) return Results.Forbid();
    return Results.Ok(await db.EventResults.AsNoTracking().Where(x => x.EventId == eventId).OrderBy(x => x.FinishPosition).Select(x => new { x.ParticipantId, ParticipantName = x.Participant!.FullName, x.FinishTime, x.FinishPosition }).ToListAsync());
});

// Optional local development seeding. It creates one sample category only; no default credentials are created.
if (app.Configuration.GetValue<bool>("Database:SeedSampleCategory"))
{
    using var scope = app.Services.CreateScope();
    var db = scope.ServiceProvider.GetRequiredService<RaceDayDbContext>();
    if (!await db.Categories.AnyAsync()) { db.Categories.Add(new Category { Name = "Open 10km", AgeGroup = "Open", DistanceKm = 10 }); await db.SaveChangesAsync(); }
}

app.Run();

public partial class Program { }
