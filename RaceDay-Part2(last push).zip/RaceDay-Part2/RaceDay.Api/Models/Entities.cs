namespace RaceDay.Api.Models;

public static class Roles
{
    public const string Organizer = "Organizer";
    public const string Participant = "Participant";
    public static bool IsValid(string? role) => role is Organizer or Participant;
}

public sealed class ApplicationUser
{
    public int Id { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string Role { get; set; } = Roles.Participant;
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}

public sealed class Event
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTime EventDate { get; set; }
    public string Location { get; set; } = string.Empty;
    public decimal DistanceKm { get; set; }
    public string EventType { get; set; } = "run";
    public int OrganizerId { get; set; }
    public ApplicationUser? Organizer { get; set; }
    public ICollection<EventCategory> Categories { get; set; } = new List<EventCategory>();
}

public sealed class Category
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? AgeGroup { get; set; }
    public decimal? DistanceKm { get; set; }
    public ICollection<EventCategory> EventCategories { get; set; } = new List<EventCategory>();
}

public sealed class EventCategory
{
    public int EventId { get; set; }
    public Event? Event { get; set; }
    public int CategoryId { get; set; }
    public Category? Category { get; set; }
}

public sealed class EventEnrolment
{
    public int Id { get; set; }
    public int ParticipantId { get; set; }
    public ApplicationUser? Participant { get; set; }
    public int EventId { get; set; }
    public Event? Event { get; set; }
    public int CategoryId { get; set; }
    public Category? Category { get; set; }
    public DateTime EnrolledAtUtc { get; set; } = DateTime.UtcNow;
}

public sealed class EventResult
{
    public int Id { get; set; }
    public int EventId { get; set; }
    public Event? Event { get; set; }
    public int ParticipantId { get; set; }
    public ApplicationUser? Participant { get; set; }
    public TimeSpan? FinishTime { get; set; }
    public int FinishPosition { get; set; }
    public DateTime RecordedAtUtc { get; set; } = DateTime.UtcNow;
}
