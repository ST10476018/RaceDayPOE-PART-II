/* RaceDay SQL Server schema. Prefer EF Core migrations for normal development.
   Run this script only against a new/empty RaceDayDb database. */
IF DB_ID(N'RaceDayDb') IS NULL CREATE DATABASE RaceDayDb;
GO
USE RaceDayDb;
GO
IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Users (
  Id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Users PRIMARY KEY,
  FullName nvarchar(120) NOT NULL,
  Email nvarchar(256) NOT NULL,
  PasswordHash nvarchar(max) NOT NULL,
  Role nvarchar(20) NOT NULL,
  CreatedAtUtc datetime2 NOT NULL CONSTRAINT DF_Users_CreatedAtUtc DEFAULT SYSUTCDATETIME(),
  CONSTRAINT UQ_Users_Email UNIQUE (Email),
  CONSTRAINT CK_Users_Role CHECK (Role IN (N'Organizer', N'Participant'))
 );
END;
GO
IF OBJECT_ID(N'dbo.Events', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Events (
  Id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Events PRIMARY KEY,
  Name nvarchar(150) NOT NULL,
  Description nvarchar(max) NOT NULL,
  EventDate datetime2 NOT NULL,
  Location nvarchar(200) NOT NULL,
  DistanceKm decimal(8,2) NOT NULL,
  EventType nvarchar(10) NOT NULL,
  OrganizerId int NOT NULL,
  CONSTRAINT CK_Events_Distance CHECK (DistanceKm > 0),
  CONSTRAINT CK_Events_Type CHECK (EventType IN (N'run', N'walk', N'cycle')),
  CONSTRAINT FK_Events_Users_OrganizerId FOREIGN KEY (OrganizerId) REFERENCES dbo.Users(Id)
 );
END;
GO
IF OBJECT_ID(N'dbo.Categories', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.Categories (
  Id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Categories PRIMARY KEY,
  Name nvarchar(100) NOT NULL,
  AgeGroup nvarchar(max) NULL,
  DistanceKm decimal(8,2) NULL,
  CONSTRAINT CK_Categories_Distance CHECK (DistanceKm IS NULL OR DistanceKm > 0)
 );
END;
GO
IF OBJECT_ID(N'dbo.EventCategories', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.EventCategories (
  EventId int NOT NULL,
  CategoryId int NOT NULL,
  CONSTRAINT PK_EventCategories PRIMARY KEY (EventId, CategoryId),
  CONSTRAINT FK_EventCategories_Events_EventId FOREIGN KEY (EventId) REFERENCES dbo.Events(Id) ON DELETE CASCADE,
  CONSTRAINT FK_EventCategories_Categories_CategoryId FOREIGN KEY (CategoryId) REFERENCES dbo.Categories(Id)
 );
END;
GO
IF OBJECT_ID(N'dbo.EventEnrolments', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.EventEnrolments (
  Id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_EventEnrolments PRIMARY KEY,
  ParticipantId int NOT NULL,
  EventId int NOT NULL,
  CategoryId int NOT NULL,
  EnrolledAtUtc datetime2 NOT NULL CONSTRAINT DF_EventEnrolments_EnrolledAtUtc DEFAULT SYSUTCDATETIME(),
  CONSTRAINT UQ_EventEnrolments_Participant_Event UNIQUE (ParticipantId, EventId),
  CONSTRAINT FK_EventEnrolments_Users_ParticipantId FOREIGN KEY (ParticipantId) REFERENCES dbo.Users(Id),
  CONSTRAINT FK_EventEnrolments_Events_EventId FOREIGN KEY (EventId) REFERENCES dbo.Events(Id) ON DELETE CASCADE,
  CONSTRAINT FK_EventEnrolments_Categories_CategoryId FOREIGN KEY (CategoryId) REFERENCES dbo.Categories(Id)
 );
END;
GO
IF OBJECT_ID(N'dbo.EventResults', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.EventResults (
  Id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_EventResults PRIMARY KEY,
  EventId int NOT NULL,
  ParticipantId int NOT NULL,
  FinishTime time NULL,
  FinishPosition int NOT NULL,
  RecordedAtUtc datetime2 NOT NULL CONSTRAINT DF_EventResults_RecordedAtUtc DEFAULT SYSUTCDATETIME(),
  CONSTRAINT UQ_EventResults_Event_Participant UNIQUE (EventId, ParticipantId),
  CONSTRAINT CK_EventResults_Position CHECK (FinishPosition > 0),
  CONSTRAINT FK_EventResults_Events_EventId FOREIGN KEY (EventId) REFERENCES dbo.Events(Id) ON DELETE CASCADE,
  CONSTRAINT FK_EventResults_Users_ParticipantId FOREIGN KEY (ParticipantId) REFERENCES dbo.Users(Id)
 );
END;
GO
